/**
 * @file 主程序入口文件
 * @module index
 */

import AutoReply from './services/AutoReply.js';
import { CHAT_URL, RANDOM_RESPONSES } from './config/constants.js';
import { getRandomElement, wait } from './utils/helpers.js';

/**
 * 主函数,初始化自动回复并开始处理聊天
 * @async
 */
async function main() {
    const autoReply = new AutoReply();
    await autoReply.init();
    await autoReply.goto(CHAT_URL);

    while (true) {
        try {
            await processChats(autoReply);
        } catch (error) {
            console.debug(error.toString());
            await wait(10000);
        }
    }
}

/**
 * 处理聊天的主要逻辑
 * @async
 * @param {AutoReply} autoReply - AutoReply 实例
 */
async function processChats(autoReply) {
    await wait(2000);
    await clickTabs(autoReply);
    await filterMessages(autoReply);
    
    const candidateInfo = await getCandidateInfo(autoReply);
    
    if (candidateInfo.isMessageSent) {
        await sendRandomResponse(autoReply);
        return;
    }

    if (!isCandidateQualified(candidateInfo)) {
        return;
    }

    await sendInitialMessage(autoReply);
    await requestResume(autoReply);
}

/**
 * 点击聊天标签
 * @async
 * @param {AutoReply} autoReply - AutoReply 实例
 */
async function clickTabs(autoReply) {
    await autoReply.moveAndClickElement('.chat-filter-container .chat-label-item:nth-child(1)');
    await wait(500);
    await autoReply.moveAndClickElement('.chat-filter-container .chat-label-item:nth-child(2)');
}

/**
 * 过滤消息
 * @async
 * @param {AutoReply} autoReply - AutoReply 实例
 */
async function filterMessages(autoReply) {
    await autoReply.moveAndClickElement('.chat-message-filter > div > span:nth-child(2)');
}

/**
 * 获取候选人信息
 * @async
 * @param {AutoReply} autoReply - AutoReply 实例
 * @returns {Promise<Object>} 候选人信息对象
 */
async function getCandidateInfo(autoReply) {
    await autoReply.moveAndClickElement('.user-list .badge-count-common-less');
    
    await wait(1000);
    
    const hasVueNodeJsNodejs = await checkResumeForSkills(autoReply);
    
    return await autoReply.page.evaluate(evaluateCandidateInfo, hasVueNodeJsNodejs);
}

/**
 * 检查简历中是否包含Vue/Node.js/NodeJS
 * @async
 * @param {AutoReply} autoReply - AutoReply 实例
 * @returns {Promise<boolean>} 是否包含Vue/Node.js/NodeJS
 */
async function checkResumeForSkills(autoReply) {
    await autoReply.moveAndClickElement('.resume-btn-content > a');
    await wait(1000);
    
    const resumeContent = await autoReply.page.evaluate(() => {
        const resumeDialog = document.querySelector('.resume-container .boss-popup__content');
        return resumeDialog ? resumeDialog.textContent : '';
    });
    
    await autoReply.moveAndClickElement('.boss-popup__close > i');
    
    return resumeContent.toLowerCase().includes('vue') || 
           resumeContent.toLowerCase().includes('node.js') || 
           resumeContent.toLowerCase().includes('nodejs');
}

/**
 * 评估候选人信息
 * @param {boolean} hasVueNodeJsNodejs - 是否包含Vue/Node.js/NodeJS
 * @returns {Object} 候选人信息对象
 */
function evaluateCandidateInfo(hasVueNodeJsNodejs) {
    const baseInfo = document.querySelector('.base-info-single-detial');
    if (!baseInfo) return { isGraduate: true, isUndergraduateOrMaster: true, isWomen: false, isMessageSent: false, hasVueNodeJsNodejs };
    
    const textContent = baseInfo.textContent;
    const htmlContent = baseInfo.innerHTML;
    
    return {
        isGraduate: textContent.includes('25年') || textContent.includes('26年'),
        isUndergraduateOrMaster: textContent.includes('本科') || textContent.includes('硕士') || textContent.includes('博士'),
        isWomen: htmlContent.includes('icon-icon-women'),
        isMessageSent: Array.from(document.querySelectorAll('.item-myself .text span')).map(span => span.innerText).includes('你好'),
        hasVueNodeJsNodejs
    };
}

/**
 * 判断候选人是否符合条件
 * @param {Object} candidateInfo - 候选人信息对象
 * @returns {boolean} 是否符合条件
 */
function isCandidateQualified(candidateInfo) {
    const { isGraduate, isUndergraduateOrMaster, isWomen, hasVueNodeJsNodejs } = candidateInfo;
    const reasons = [];
    
    if (!isGraduate) reasons.push('不是应届生');
    if (!isUndergraduateOrMaster) reasons.push('不是本科或硕士或博士');
    if (isWomen) reasons.push('是女性');
    if (!hasVueNodeJsNodejs) reasons.push('简历中不包含Vue/Node.js/NodeJS');
    
    const isQualified = isGraduate && isUndergraduateOrMaster && !isWomen && hasVueNodeJsNodejs;
    console.debug(`判断结果: ${isQualified ? '继续' : '跳过'}, 原因: ${reasons.join('，')}`);
    
    return isQualified;
}

/**
 * 发送随机回复
 * @async
 * @param {AutoReply} autoReply - AutoReply 实例
 */
async function sendRandomResponse(autoReply) {
    await wait(1000 + Math.random() * 2000);
    await autoReply.sendMessage(getRandomElement(RANDOM_RESPONSES));
}

/**
 * 发送初始消息
 * @async
 * @param {AutoReply} autoReply - AutoReply 实例
 */
async function sendInitialMessage(autoReply) {
    await autoReply.sendMessage('你好');
    await wait(1000);
}

/**
 * 请求简历
 * @async
 * @param {AutoReply} autoReply - AutoReply 实例
 */
async function requestResume(autoReply) {
    await autoReply.moveAndClickElement('.operate-exchange-left span.operate-btn');
    await wait(500);
    await autoReply.moveAndClickElement('.toolbar-box-right .operate-exchange-left .boss-btn-primary');
}

main().catch(console.error);
