
# 自动回复BOSS直聘 zhipin-auto-reply

zhipin-auto-reply 是一个自动回复和处理BOSS直聘聊天的Node.js应用程序。

## 功能特点

- 自动浏览和处理BOSS直聘的聊天消息
- 根据预设条件筛选候选人
- 自动发送初始消息和请求简历
- 模拟真实的鼠标移动和点击行为


## 安装

确保您的系统中已安装Node.js和Yarn。然后，按照以下步骤进行安装：

1. 进入项目目录：
   ```
   cd zhipin-auto-reply
   ```

2. 安装依赖：
   ```
   yarn install
   ```

## 使用方法

1. 确保您已经登录了BOSS直聘网站，并且浏览器已经在运行。

2. 运行程序：
   ```
   yarn start
   ```

3. 程序将自动连接到浏览器，并开始处理聊天消息。

## 配置

您可以在 `src/config/constants.js` 文件中修改以下配置：


```6:13:zhipin-auto-reply/src/config/constants.js
/** @constant {string} BROWSER_URL - 浏览器 URL */
export const BROWSER_URL = 'http://127.0.0.1:9333';

/** @constant {string} CHAT_URL - 聊天页面 URL */
export const CHAT_URL = 'https://www.zhipin.com/web/chat/index';

/** @constant {string[]} RANDOM_RESPONSES - 随机回复列表 */
export const RANDOM_RESPONSES = ['好的', '好', 'OK', '收到', '收到，我看看', '好的，我看看'];
```


## 项目结构

- `src/index.js`: 主程序入口文件
- `src/services/AutoReply.js`: AutoReply 类定义，处理自动回复和浏览器操作
- `src/utils/helpers.js`: 辅助函数
- `src/config/constants.js`: 常量定义

## 依赖

- puppeteer: 用于控制浏览器
- node-fetch: 用于网络请求

## 注意事项

- 请确保您的使用符合BOSS直聘的用户协议和相关法律法规。
- 本程序仅用于学习和研究目的，不应用于任何非法或不道德的用途。
